# @bestcoder/react-native-data-table

> 依赖：`@shopify/flash-list` v2（万级数据虚拟化）
> 跨端：App（iOS / Android）与 Web (H5) 行为一致

## 安装

```bash
npm install @bestcoder/react-native-data-table @shopify/flash-list
```

## 文件结构

| 文件 | 职责 |
|---|---|
| `data-table.tsx` | 主组件：列装配、FlashList 装配、幽灵测绘调度（状态逻辑在下面三个 hook） |
| `use-column-measure.ts` | 测绘状态机 hook：首测/原地重测双通道、测绘缓存生命周期、子表宽度并入 |
| `use-row-selection.ts` | 行选择 hook：单行切换、全选/反选、命令式 selectAll/clearSelection |
| `use-expandable.ts` | 展开行 hook：展开集合、子表异步取数（loading/done/error）与重试 |
| `column-layout.ts` | 纯函数：列装配（选择列注入 + 固定列归位）与列宽解析，配套单元测试 |
| `expanded-area.tsx` | 展开区：custom 固定面板 / sub-table 四态（loading/error/empty/联动子表） |
| `sub-table.tsx` | 子表实体渲染（`SubTable`，复用父 `CellBox` 钉固定列）+ 离屏测量（`SubTableMeasurer`，撑宽父列） |
| `border.ts` | 纯函数：`border` 配置 → 行/单元格/外框三类样式 |
| `header-row.tsx` | 表头行（memo）：排序箭头、全选 Checkbox |
| `table-row.tsx` | 数据行（memo）：单元格铺设、按压高亮、点击展开、行选择框 |
| `cell-box.tsx` | 单元格外框：定宽、对齐、双端固定列钉住 |
| `h-scroller.tsx` | H5 行内横向滚动器：registry 广播同步、滚动所有权 |
| `checkbox.tsx` | 极简跨端 Checkbox（选中 / 半选 / 禁用） |
| `cell.tsx` | 单元格内容与样式链唯一入口（真实渲染与幽灵测绘共用） |
| `measure.ts` | 离屏测量共享钩子 `useMeasure` + 容器样式（父表幽灵测绘与子表测量共用） |
| `theme.ts` | 主题契约 `DataTableTheme` + 内置默认 + Context/`useDataTableTheme`（配色注入，全组件唯一颜色来源） |
| `ghost-measurer.tsx` | 父表离屏幽灵测绘区 |
| `types.ts` | 对外类型契约 |

## 特性一览

- **万级数据流畅滚动**：FlashList v2 虚拟化，支撑 10,000+ 行。
- **双向滚动 + 吸顶表头**：纵向滚动表头吸顶（哨兵行 + `stickyHeaderIndices`），横向滚动表头与所有行同步；`stickyHeader={false}` 关闭吸顶。
- **左右双侧固定列**：`fixed: 'left' | 'right'`。App 端原生 `translateX` 无延迟钉住，Web 端 CSS `position: sticky`。
- **页面级头部/尾部**：`ListHeaderComponent` / `ListFooterComponent` 只随纵向滚动，不随横向滚动。
- **列宽自适应（幽灵测绘）**：未设 `width` 的列按真实渲染内容自动撑宽、不换行，滑动期间零 `onLayout` 开销；`remeasureKey` 触发原地重测（行不下屏、纵向不回顶）。
- **弹性撑满容器**：总列宽不足时自适应列均分剩余空间填满屏幕，溢出时横向滚动、绝不压缩。
- **折叠展开行 / 异步主子表**：`renderExpandedRow` 自定义详情面板，或 `sub-table` 模式异步联动子表（横滚/固定列可与父表联动）。
- **万级行选择**：`rowSelection` 开启 Checkbox 列，支持独立/合并列、全选/半选/按行禁用、`ref` 命令式 `selectAll` / `clearSelection`；单行勾选只重渲染受影响行。
- **列排序**：`sorter: true` 表头可点击，`currentSort` 受控，按 null → ascend → descend → null 轮转触发 `onSort`（组件不排序数据）。
- **斑马纹 / 按压高亮**：`striped` + `stripeColors`、`highlightOnRowPress` + `highlightColor`，固定列同步换底色。
- **自定义单元格 / 表头 + 三级样式覆盖**：列 `render` / `renderHeader`；全局 `cellStyle` → 列 `cellStyle` → `renderCellStyle`（动态、优先级最高）。
- **下拉刷新 / 上拉加载**：`refreshing` + `onRefresh` / `onEndReached`（幽灵测绘/重测期间自动屏蔽防重复翻页）。
- **边框可配**：`border` 行/列/外框三类线独立开关。
- **高度可配**：`height` 定高 / `maxHeight` 上限 / 默认随父 flex 撑满。

## 快速上手

```tsx
import { DataTable, type TableColumn } from '@bestcoder/react-native-data-table';

interface Order {
  id: string;
  customer: string;
  amount: number;
  status: 'paid' | 'pending' | 'error';
}

const columns: TableColumn<Order>[] = [
  { title: '订单号', dataIndex: 'id', width: 100, fixed: 'left' },
  { title: '客户', dataIndex: 'customer', minWidth: 120 },
  { title: '金额', dataIndex: 'amount', align: 'right' },
  { title: '状态', dataIndex: 'status' },
];

export function OrderList() {
  return (
    <DataTable
      data={orders}
      columns={columns}
      keyExtractor={(item) => item.id}
    />
  );
}
```

## Props

### `DataTableProps<T>`

| Prop | 类型 | 必填 | 说明 |
|---|---|---|---|
| `data` | `T[]` | ✅ | 原始数据源 |
| `columns` | `TableColumn<T>[]` | ✅ | 列配置，见下表 |
| `keyExtractor` | `(item: T, index: number) => string` | ✅ | 行唯一 key，**必须稳定**（幽灵测绘按 key 放行数据） |
| `remeasureKey` | `string \| number` | — | 重测信号：值变化时对当前数据整体重新测绘并替换列宽（原地进行，行不下屏、纵向滚动不回顶）。典型用法：传入全局字体缩放倍率 `remeasureKey={useFontScale()}` |
| `height` | `DimensionValue` | — | 固定整体高度，优先级最高 |
| `maxHeight` | `DimensionValue` | — | 在父 flex 布局内自然撑高但不超过此值 |
| `striped` | `boolean` | — | 斑马纹开关 |
| `stripeColors` | `[string, string]` | — | 交替背景色（偶、奇行），默认 `[Palette.card, Palette.bg]` |
| `highlightOnRowPress` | `boolean` | — | 行按压时高亮 |
| `highlightColor` | `string` | — | 按压高亮色，默认 `Palette.primaryLight` |
| `rowSelection` | `RowSelectionConfig<T>` | — | 行选择配置，不传则不渲染选择列，见下文。需要「按钮切换批量选择模式」时条件传参即可（`selecting ? {...} : undefined`），切换自动原地重测列宽 |
| `stickyHeader` | `boolean` | — | 表头是否吸顶，默认 `true`；`false` 时表头随内容纵向滚走（横向仍与行同步） |
| `ref` | `Ref<DataTableHandle>` | — | 命令式句柄，暴露 `selectAll()` / `clearSelection()`（React 19 ref-as-prop） |
| `onSort` | `(params: SortParams) => void` | — | 表头排序点击回调 |
| `currentSort` | `SortParams` | — | 当前排序状态（受控），驱动表头箭头 UI |
| `renderSortIcon` | `(order) => ReactNode` | — | 自定义排序图标（全局，所有 sorter 列共用）；不传用内置 ▲▼（按 `theme.primary/disabled` 上色）。三态图标宽度须一致，否则切排序时列宽抖动 |
| `ListHeaderComponent` | `ComponentType \| ReactElement \| null` | — | 页面级头部，只随纵向滚动（如资金看板） |
| `ListFooterComponent` | `ComponentType \| ReactElement \| null` | — | 页面级尾部，只随纵向滚动（如底部 Loading） |
| `refreshing` | `boolean` | — | 下拉刷新中状态 |
| `onRefresh` | `() => void` | — | 下拉刷新回调 |
| `onEndReached` | `() => void` | — | 触底加载更多（幽灵测绘扣留数据期间自动屏蔽，防重复翻页） |
| `onEndReachedThreshold` | `number` | — | 触底阈值，同 FlashList |
| `expandedRowType` | `'custom' \| 'sub-table'` | — | 展开模式，默认 `'custom'`，见「展开行与主子表」 |
| `expandedRowStyle` | `StyleProp<ViewStyle>` | — | 展开区容器样式 |
| `renderExpandedRow` | `(record, index, columnWidths, subData?) => ReactNode` | — | 传入后行可点击。`custom` 模式渲染固定详情面板（占满视口、横滑不动）；第三参为父表最终列宽数组 |
| `onExpandFetch` | `(record, index) => Promise<D>` | — | 展开时异步取子表数据，结果按行 key 缓存，取数期间展示 Loading |
| `getSubTable` | `(record, index, subData) => SubTableSpec` | — | `sub-table` 模式：由子数据产出子表规格（行数据 + 列定义） |
| `isExpandedDataEmpty` | `(subData) => boolean` | — | 判空，默认 null/空数组视为空（空态走固定面板） |
| `renderExpandedLoading/Error/Empty` | `(columnWidths) => ReactNode` | — | 加载中 / 失败 / 空 面板（固定面板），有默认实现 |
| `subTableSyncScroll` | `boolean` | — | 子表横滚是否与父表联动，默认 `true`；`false`=独立横滚 |
| `subTableSyncFixedColumns` | `boolean` | — | 子表是否同步父表固定列钉住，默认 `true` |
| `style` | `StyleProp<ViewStyle>` | — | 最外层容器样式 |
| `headerStyle` | `StyleProp<ViewStyle>` | — | 表头行样式 |
| `headerTextStyle` | `StyleProp<TextStyle>` | — | 表头文字样式（同时参与幽灵测宽） |
| `rowStyle` | `StyleProp<ViewStyle>` | — | 数据行样式 |
| `cellStyle` | `StyleProp<ViewStyle>` | — | 全局单元格基础样式（如统一 padding），可被列级覆盖 |
| `cellTextStyle` | `StyleProp<TextStyle>` | — | 全局单元格默认文字样式（`fontSize`/`color` 等），仅作用于未走 `col.render` 的默认文本；与 `headerTextStyle` 对称 |
| `border` | `boolean \| DataTableBorder` | — | 边框配置，见「边框」。省略=仅横向行分隔线 |
| `theme` | `Partial<DataTableTheme>` | — | 主题色注入，见「主题」。与内置默认深合并，只覆盖传入的键；不传用内置默认 |
| `ListEmptyComponent` | `ComponentType \| ReactElement \| null` | — | 空态（仅 `data` 为空时显示） |

> 泛型：`DataTable<T, D>`——`T` 父行数据类型，`D` 子表异步数据类型（默认 `unknown`）。

### `TableColumn<T>`

| 字段 | 类型 | 说明 |
|---|---|---|
| `title` | `string` | 表头标题 |
| `dataIndex` | `keyof T \| string` | 取值字段；无 `render` 时按此字段渲染文本 |
| `width` | `number` | 固定列宽。设置后：跳过幽灵测算，也不参与弹性空间分配 |
| `minWidth` | `number` | 自适应列的最小宽度（测宽结果与其取最大值） |
| `align` | `'left' \| 'center' \| 'right'` | 内容与表头对齐，默认 `left` |
| `fixed` | `'left' \| 'right'` | 固定列不随横向滚动。内部会自动把左固定列归位到最前、右固定列归位到最后（各组内保持声明顺序） |
| `sorter` | `boolean` | 该列表头可点击排序，配合 `onSort` / `currentSort` 使用 |
| `cellStyle` | `StyleProp<ViewStyle>` | 单列单元格样式，**同时作用于表头与数据单元格**，覆盖全局 `cellStyle` |
| `renderCellStyle` | `(record, index) => StyleProp<ViewStyle>` | 按行数据动态返回样式（背景色、边框等），**优先级最高（仅数据单元格）** |
| `render` | `(record, index) => ReactNode` | 自定义数据单元格内容，支持任意复杂组件 |
| `renderHeader` | `() => ReactNode` | 自定义表头单元格内容（优先于 `title`）；同样参与幽灵测宽，须纯展示、不加 `numberOfLines` |
| `headerCellStyle` | `StyleProp<ViewStyle>` | 表头单元格独立样式（不影响该列数据单元格），优先级高于 `col.cellStyle` |
| `headerTextStyle` | `StyleProp<TextStyle>` | 列级表头文字样式（覆盖全局 `headerTextStyle`），仅默认标题文本渲染时生效 |

**样式链优先级**（低 → 高）：
- 数据单元格：内置基础样式（padding 12/10）→ 全局 `cellStyle` → 列 `cellStyle` → `renderCellStyle`。
- 表头单元格：内置基础样式 → 全局 `cellStyle` → 列 `cellStyle`（与数据单元格共享）→ 列 `headerCellStyle`。
- 表头文字：内置 `headerTextBase` → 全局 `headerTextStyle` → 列 `headerTextStyle`。

最终列宽在样式链之后强制追加，无法被样式覆盖。

### `RowSelectionConfig<T>`

| 字段 | 类型 | 说明 |
|---|---|---|
| `selectedRowKeys` | `string[]` | 当前选中行 key（受控） |
| `onChange` | `(keys: string[], rows: T[]) => void` | 选中变化回调，`keys`/`rows` 按 `data` 顺序回吐 |
| `getCheckboxProps` | `(record: T) => { disabled?: boolean }` | 按行禁用 Checkbox；禁用行不参与全选/反选 |
| `position` | `'first' \| 'last'` | 选择列位置，默认 `'first'`。`'first'` 自动归入**最左固定列流**、`'last'` 归入**最右固定列流**（同步悬浮）。设 `mergeIntoDataIndex` 后忽略 |
| `renderCheckbox` | `(selected, record) => ReactNode` | 自定义行选择框 UI（纯展示，按压由组件处理）。选中/未选两态宽度须一致 |
| `renderHeaderCheckbox` | `({ checked, indeterminate, disabled }) => ReactNode` | 自定义表头全选框 UI（含半选态；与 `renderCheckbox` 对称） |
| `mergeIntoDataIndex` | `string` | 将选择框合并进指定 `dataIndex` 的现有列，而非独立建列。宿主列不存在时 `__DEV__` 告警并回退为独立选择列 |
| `checkboxAlign` | `'top' \| 'center' \| 'bottom'` | 合并模式下选择框在单元格内的垂直对齐，默认 `'center'` |

### `DataTableHandle`（`ref`）/ `SortParams`

- `selectAll()`：全选所有未禁用行（已选中的禁用行保持原状）。
- `clearSelection()`：清空**可选行**的选中；禁用行的已选状态**保留**。
- `SortParams`：`{ dataIndex: string; order: 'ascend' | 'descend' | null }`——被点击列与目标方向（`null` 取消排序）。

## 展开行与主子表

点击行在其下方展开内容，两种模式：

### 模式 A：`custom`（默认，固定详情面板）

`renderExpandedRow(record, index, columnWidths, subData?)` 返回自定义内容（大文本、图表等）。渲染在**横向滚动容器外层**：占满视口宽 100%，主表左右横滑时**保持固定、绝不横滚**。第三参 `columnWidths` 是父表最终列宽像素数组（视觉顺序，和为总宽）。

### 模式 B：`sub-table`（异步联动子表）

由「行数据 + 列定义」驱动，与父表 `data × columns` 对称。子表**无表头**、字段/结构与父表**完全独立**。

```tsx
<DataTable<Note, Lot[]>
  data={notes}
  columns={HOLDINGS_COLUMNS}
  expandedRowType="sub-table"
  onExpandFetch={(note) => fetchLots(note.id)}   // 异步取数 → subData，取数期间展示 Loading
  getSubTable={(note, index, lots): SubTableSpec<Lot> => ({
    rows: lots,                                    // 子表行数据（独立结构）
    cellStyle: { paddingVertical: 4 },
    columns: [
      { colIndex: 0, render: (lot) => <Text>{lot.date}</Text> },   // 对齐父第0列（复用宽度/固定钉住）
      { colIndex: 1, dataIndex: 'qty', align: 'right' },           // 取字段渲染文本
      { colIndex: 3, align: 'right',
        renderCellStyle: (lot) => lot.pnl < 0 ? { backgroundColor: '#fde8e8' } : undefined,
        render: (lot) => <Text>{formatSigned(lot.pnl)}</Text> },   // 逐格动态样式 + 自定义内容
      // 未定义的父列自动填等宽空占位，保持对齐
    ],
  })}
/>
```

- **列宽/固定复用**：`SubColumn.colIndex` 对齐父表视觉列序；子格宽度复用父列宽，父列 `fixed` 时子格同步钉住。
- **子内容驱动列宽**：子格自然宽经离屏测量并入父表列宽（取 max）撑宽自适应列——父数据行与子表始终对齐（测完再上屏，无闪跳）。
- **非数据态**：`loading` / `error` / 空 均以**固定面板**呈现（占满视口、横滑不动），可用 `renderExpandedLoading/Error/Empty` 定制。
- **联动开关**：`subTableSyncScroll`（横滚联动，默认 true）× `subTableSyncFixedColumns`（固定列同步，默认 true）四种组合——true/true 与父表同滚且同步钉住（默认）；其余组合按需放开独立横滚 / 不钉固定列。

#### `SubColumn<S>` / `SubTableSpec<S>`

| `SubColumn` 字段 | 类型 | 说明 |
|---|---|---|
| `colIndex` | `number` | 对齐父表视觉列序的第几列（复用宽度 + 固定钉住） |
| `colSpan` | `number` | 跨列，宽度取对应父列宽之和（跨列格不参与测量/钉住） |
| `dataIndex` | `keyof S \| string` | 取值字段（无 `render` 时渲染文本） |
| `align` | `'left'\|'center'\|'right'` | 默认继承父列 |
| `cellStyle` / `renderCellStyle` / `render` | 同父表 `TableColumn`（逐格样式 + 动态样式 + 自定义内容） |

`SubTableSpec`：`rows: S[]` + `columns: SubColumn<S>[]` + `rowStyle?` + `cellStyle?` + `cellTextStyle?`（子单元格默认文字样式，仅作用于未走子列 `render` 的默认文本）。

## 边框

`border`：省略 = 仅横向行分隔线（默认）；`false` = 全关；`true` = 开启横线；对象 = 三类线独立开关、共用 `color`/`width`。

| `DataTableBorder` 字段 | 默认 | 说明 |
|---|---|---|
| `color` | `theme.line` | 线色 |
| `width` | `hairline` | 线宽 px |
| `horizontal` | `true` | 行分隔线（行间 + 表头/表体） |
| `vertical` | `false` | 列分隔竖线（**参与幽灵测宽**） |
| `outer` | `false` | 表格外边框 |

完整网格：`border={{ horizontal: true, vertical: true, outer: true, color: '#ddd', width: 1 }}`。`border` 为基础线层，`headerStyle`/`rowStyle`/`cellStyle` 仍可覆盖。

## 主题

组件**零依赖、自带默认配色**，不 import 项目任何文件。全部颜色收敛在 `DataTableTheme`（9 个 token），经 `theme?: Partial<DataTableTheme>` prop 注入、与内置默认深合并（只覆盖传入的键），内部用 Context 分发到各子组件。不传 `theme` 也能独立运行。

| `DataTableTheme` token | 用途 |
|---|---|
| `headerBg` | 表头 / 固定表头格 / 展开区 / 斑马纹奇行默认 |
| `rowBg` | 数据行 / 固定数据格 / Checkbox 底 / 斑马纹偶行默认 |
| `text` | 单元格与表头文字 |
| `textSecondary` | 加载失败 / 空态文字 |
| `primary` | Checkbox 选中、排序箭头激活、加载转圈 |
| `primaryLight` | 行按压高亮默认色 |
| `onPrimary` | Checkbox 对勾 / 半选横杠 |
| `line` | 边框默认线色 |
| `disabled` | Checkbox 未选边框、排序箭头未激活 |

**注入项目配色**：在项目侧建配置文件把品牌色映射进来，页面传给 `theme`；个别页面可在基础上覆盖：

```tsx
// src/config/data-table.config.ts —— 全局基础主题（项目品牌 → 组件契约）
import type { DataTableTheme } from '@bestcoder/react-native-data-table';
import { Palette } from '@/constants/theme';
export const dataTableTheme: DataTableTheme = {
  headerBg: Palette.bg, rowBg: Palette.card, text: Palette.text,
  textSecondary: Palette.textSecondary, primary: Palette.primary,
  primaryLight: Palette.primaryLight, onPrimary: Palette.onPrimary,
  line: Palette.line, disabled: Palette.disabled,
};

// 页面：常规直接用基础主题；个别页面微调
<DataTable theme={dataTableTheme} … />
<DataTable theme={{ ...dataTableTheme, headerBg: '#fff' }} … />   // 例：白表头
```

也可 `import { DEFAULT_DATA_TABLE_THEME } from '@bestcoder/react-native-data-table'` 拿内置默认作基线扩展。

## 使用示例

### 1. 分页加载 + 下拉刷新

```tsx
export function BigList() {
  const [rows, setRows] = useState<Order[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const page = useRef(1);

  const loadPage = async (reset: boolean) => {
    const next = reset ? 1 : page.current + 1;
    const list = await fetchOrders(next);
    page.current = next;
    setRows((prev) => (reset ? list : [...prev, ...list]));
  };

  return (
    <DataTable
      data={rows}
      columns={columns}
      keyExtractor={(item) => item.id}
      refreshing={refreshing}
      onRefresh={async () => {
        setRefreshing(true);
        await loadPage(true);
        setRefreshing(false);
      }}
      onEndReached={() => loadPage(false)}
      onEndReachedThreshold={0.3}
    />
  );
}
```

新页数据到达后先进离屏幽灵区测算列宽，测完（通常一帧内）再追加进列表，期间 `onEndReached` 自动屏蔽以防重复请求同一页。

### 2. 自定义单元格内容（`render`）

```tsx
const columns: TableColumn<Order>[] = [
  { title: '订单号', dataIndex: 'id', width: 100, fixed: 'left' },
  { title: '状态', dataIndex: 'status', align: 'center',
    render: (record) => <StatusTag status={record.status} /> },
  { title: '操作', dataIndex: 'actions',
    render: (record, index) => (
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <Button title="编辑" onPress={() => onEdit(record)} />
        <Button title="删除" onPress={() => onDelete(record, index)} />
      </View>
    ) },
];
```

自定义内容**不要**加 `numberOfLines={1}`——列宽由幽灵测绘按真实渲染宽度保证，不会换行。

### 3. 自定义样式（三级覆盖 + 动态背景色）

```tsx
<DataTable
  data={rows}
  keyExtractor={(item) => item.id}
  cellStyle={{ paddingHorizontal: 16 }}          // 全局：统一加大边距
  columns={[
    { title: '金额', dataIndex: 'amount', align: 'right',
      cellStyle: { paddingHorizontal: 8 },       // 列级：此列收窄（覆盖全局）
      renderCellStyle: (record) =>               // 动态：负数标红底（优先级最高）
        record.amount < 0 ? { backgroundColor: '#fde8e8' } : undefined },
  ]}
/>
```

三级样式全部参与幽灵测宽：padding、边框带来的宽度变化都会计入列宽。

### 4. 固定列 + 折叠展开行

```tsx
<DataTable
  data={rows}
  keyExtractor={(item) => item.id}
  columns={[
    { title: '订单号', dataIndex: 'id', width: 100, fixed: 'left' },
    { title: '客户', dataIndex: 'customer', minWidth: 120 },
    // ... 更多列，横向滚动查看
  ]}
  renderExpandedRow={(record) => (
    <View style={{ padding: 12 }}>
      <Text>收货地址：{record.address}</Text>
      <Text>备注：{record.remark}</Text>
    </View>
  )}
/>
```

传入 `renderExpandedRow` 后整行可点击，再次点击收起；展开区行高由 FlashList v2 自动测量。

### 5. 行选择 + 排序 + 斑马纹（受控）

```tsx
export function SelectableList() {
  const [selectedKeys, setSelectedKeys] = useState<string[]>([]);
  const [sort, setSort] = useState<SortParams | undefined>();

  // 组件不排序数据：按 sort 自行处理后传入 data
  const sorted = useMemo(() => sortRows(rows, sort), [rows, sort]);

  return (
    <DataTable
      data={sorted}
      keyExtractor={(item) => item.id}
      striped
      highlightOnRowPress
      highlightColor="#e6f4ff"
      rowSelection={{
        selectedRowKeys: selectedKeys,
        onChange: (keys) => setSelectedKeys(keys),
        getCheckboxProps: (record) => ({ disabled: record.locked }),
        position: 'first',
      }}
      onSort={setSort}
      currentSort={sort}
      columns={[
        { title: '订单号', dataIndex: 'id', width: 100, fixed: 'left' },
        { title: '金额', dataIndex: 'amount', align: 'right', sorter: true },
        { title: '操作', dataIndex: 'actions', width: 120, fixed: 'right', render: renderActions },
      ]}
    />
  );
}
```

万级数据下勾选单行只有该行重渲染（切换回调恒稳定 + `TableRow` memo 拦截），全选/反选也只触达可视区行。

### 6. 列宽策略

```tsx
const columns: TableColumn<Order>[] = [
  { title: 'ID', dataIndex: 'id', width: 80 },       // ① 定宽：跳过测算、不弹性拉伸
  { title: '客户', dataIndex: 'customer', minWidth: 120 },  // ② 自适应 + 下限
  { title: '备注', dataIndex: 'remark' },            // ③ 纯自适应（含表头标题）
];
```

弹性规则：总宽 **<** 容器宽时剩余空白均分给 ②③ 类自适应列填满屏幕；总宽 **≥** 容器宽时不拉伸不压缩，直接横向滚动。

## 布局约定

- **高度三选一**：`height` 定死；或 `maxHeight`（父 flex 内撑高但不超上限）；两者都不传默认 `flex: 1` 随父容器撑满——此时父容器必须有明确高度，否则列表无法虚拟化。
- `keyExtractor` 返回值必须全局唯一且稳定，不要用数组下标——幽灵测绘按 key 判断数据是否已放行，key 不稳定会导致重复测算或行闪烁。

## 实现要点（维护者须知）

- **滚动架构**：FlashList 是**最外层纵向滚动容器**，严禁在其外层包横向 ScrollView。横向滚动下沉到表头与每一行内部的 `HScroller`（`Animated.ScrollView horizontal`）；App 端另由外层唯一横向 ScrollView 统一驱动固定列 `translateX`。`ListHeaderComponent`/`ListFooterComponent` 直接透传给 FlashList，只随纵向滚动。
- **横向同步（h-scroller.tsx）**：所有 `HScroller` 注册进共享 registry，滚动时经 `Animated.event` 的 JS listener 广播 `scrollTo`。**原生端必须按「手势所有权」限定唯一广播源**（`onTouchStart` 认领）：跟随者的回声事件是异步的，若允许其反向广播会 `scrollTo` 到正被拖动的滚动器——iOS 的 `setContentOffset` 会立即打断拖动，表现为整表无法横滑。Web 端滚轮无触摸信号，退回「偏移相同即跳过」的回声阈值判定。FlashList 复用行、Web DOM 重排会静默重置 `scrollLeft`，故 `onLayout`/`onContentSizeChange` 时都按共享 offsetRef 归位。
- **行点击（折叠展开）**：Pressable 渲染在 HScroller 的**滚动内容容器**上，严禁改回「Pressable 包裹 ScrollView」——Fabric iOS 的 `RCTScrollViewComponentView` 只要发现任一**祖先**是 JS responder 就禁用滚动手势（且忽略 `blockNativeResponder`），表现为「表头能拖、数据行拖不动」；Pressable 作为滚动内容（子孙）则点击与拖动互不干扰。
- **吸顶表头**：表头作为第 0 条哨兵数据注入 FlashList，走 `stickyHeaderIndices=[0]` 原生吸顶。哨兵导致 listData 恒非空，`ListEmptyComponent` 改注入 footer 区域渲染。`stickyHeader={false}` 时不传 `stickyHeaderIndices`。
- **固定列分平台（cell-box.tsx）**：App 端用**本行自己的** `scrollX`（原生驱动）做 `translateX` 补偿——左固定 `translateX = scrollX`，右固定 `translateX = scrollX - maxScroll`（`interpolate` 线性映射，`maxScroll = 总列宽 - 容器宽`），`scrollX=0` 钉在视口右缘、滚到最右回到自然流位置。位移用 `extrapolate: 'clamp'` **夹在 `[0, maxScroll]`**：内容变窄（字体调小重测）后系统会把可视偏移夹到新的 `maxScroll`，但 `scrollX` 可能残留旧的更大偏移，不夹紧会让固定列在最右侧过度位移脱位。Web 端 `position: sticky, left/right`，滚动容器是本行自己的 HScroller。右固定的位移换算要求右固定列连续位于行尾，故列装配阶段把 `fixed:'left'` 归位到最前、`fixed:'right'` 归位到最后。
- **列装配与列宽解析是纯函数**（`column-layout.ts` 的 `mergeColumns` / `resolveColumnLayout`），行为由 `column-layout.test.ts` 锁定，改动请先跑测试。选择列独立模式是内部注入的 48px 定宽固定列（`__DATA_TABLE_SELECTION__`），不参与测绘/弹性；合并模式（`mergeIntoDataIndex`）不注入新列，`ResolvedColumn.mergesSelection` 标记宿主列，由 `cell.tsx` 的 `renderSelectionCell` 组合 `[框][内容]`。
- **样式/内容唯一入口（cell.tsx）**：真实渲染与幽灵测绘共用 `composeCellStyle` / `composeHeaderCellStyle` / `renderHeaderContent` / `renderSelectionCell`。**改这些逻辑必须走这些函数**，否则测宽与实际渲染不一致会导致换行。
- **离屏测量唯一入口（measure.ts）**：`useMeasure(expected, onMeasured)` 收敛「逐格 onLayout 收集、同列取 max、向上取整 +1px 防换行、测满 expected 回调」的不变式，父表 `GhostMeasurer` 与子表 `SubTableMeasurer` 共用；`expected===0` 立即放行避免门控卡住。改测宽规则只需改这一处。
- **行选择性能**：`handleToggleSelect` 经 ref 透传最新 data/rowSelection，回调引用恒稳定；`TableRow` 只收 `selected: boolean` 等原始值 props，勾选一行时其余行被 memo 拦截。选中回吐统一走 `emitSelection`（按 data 顺序、剔除残留 key），全选范围统一走 `selectableKeysOf`（跳过 `getCheckboxProps().disabled`）。`selectAll`/`clearSelection` 经 `useImperativeHandle` + `selectionStateRef` 读最新 data；`clearSelection` 只清可选行，禁用行的已选状态保留。
- **斑马纹/按压高亮与固定列**：行背景经 `rowBackground`/按压态算出唯一 `effectiveBg`，同时写入行容器与固定单元格底色，避免横滑时固定列露出默认白底。
- **幽灵测绘缓存生命周期**：增量数据先在离屏区真实渲染测宽，与历史最大宽、`minWidth` 合并后放行上屏，主体滑动期间零 `onLayout`。数据整体更换（下拉刷新换 key）时清理已不在数据源中的测绘 key。测绘签名 = `remeasureKey` + 自适应列 key 集合，签名变化时若已有行上屏则走**原地重测**，尚无行上屏则作废缓存走首次测绘。
- **原地重测**：`remeasureKey` 或自适应列集合变化时——行保持旧列宽上屏，全量数据快照分批离屏重测，全部完成后一次性**替换** `measuredWidths`（合并取 max 无法让列缩窄，必须替换）。期间 `onEndReached` 屏蔽，经 pending 通道上屏的新行宽度同步并入重测累加器。行不下屏、纵向滚动位置不变；代价是宽度不足的单元格在替换完成前短暂换行。
- **分批测绘**：单批上限 200 行（`MEASURE_BATCH_SIZE`），pending 通道与重测通道都按批推进，避免一次性挂载万级离屏单元格重帧。
- **展开区双模式布局（expanded-area.tsx）**：`custom` 模式 = 固定面板（Native `width=containerWidth` + `translateX=nativeScrollX` 反向补偿；Web 为 HScroller 兄弟 View），占满视口横滑不动。`sub-table` done+有数据时走 `SubTable`（`sub-table.tsx`，按父表视觉列序铺子行、复用父 `CellBox` 钉固定列）；`loading`/`error`/`empty` 一律走固定面板。子格自然宽经 `SubTableMeasurer` 离屏测量并入父表 `measuredWidths` 撑宽自适应列，`subMeasuredKeys` 门控测完再上屏；列宽体系重算时 `subMeasuredKeys` 作废、子表重测。
- **异步取数**：`onExpandFetch` 结果按行 key 存入 `asyncState`（loading/done/error），并入 `extraData` 让 FlashList 回收行刷新。取数/展开决策经 `expandCfgRef` 读最新 props，回调恒稳定。
- **边框（border.ts，纯函数）**：`resolveBorder` 把配置解析为 row（行底横线）/ cell（单元格右竖线，经共享样式链进 `CellBox` 与 `GhostMeasurer` 保证测宽一致）/ outer（外框）三类。改竖线务必两处同步。
- **配色（theme.ts）**：组件**零依赖自洽**——不 import 项目任何文件，`DEFAULT_DATA_TABLE_THEME` 内置一套默认配色。全部颜色收敛为 `DataTableTheme` 的 9 个 token，经 `theme` prop 注入、Context 分发；叶子组件走 `useDataTableTheme()`，纯函数（`cell.tsx` 的 render 系列 / `border.ts`）则由调用方把颜色作参数传入。项目配色经外部配置文件（如 `src/config/data-table.config.ts`）映射 `Palette` → `theme` 注入，组件本身与项目配色解耦。

## License

[MIT](./LICENSE) © bestcoder
